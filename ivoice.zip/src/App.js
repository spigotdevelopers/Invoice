import './App.css';
import Invoive from './component/invoive';

function App() {
  return (
    <div className="App">
      <Invoive />
    </div>
  );
}

export default App;
  